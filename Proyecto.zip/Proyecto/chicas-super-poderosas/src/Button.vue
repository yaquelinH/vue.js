<!-- Button.vue -->

<template>
    <button @click="handleClick" :class="buttonClass">
      {{ buttonText }}
    </button>
  </template>
  
  <script>
  export default {
    props: {
      buttonText: {
        type: String,
        required: true
      },
      buttonClass: {
        type: String,
        default: ''
      }
    },
    methods: {
      handleClick() {
        // Aquí puedes agregar la lógica para manejar el clic del botón
        console.log('¡Botón clickeado!');
      }
    }
  }
  </script>
  
  <style scoped>
  /* Estilos específicos del componente */
  button {
    /* Estilos del botón */
  }
  </style>