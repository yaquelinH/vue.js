<script setup>
import { ref, computed } from "vue";

const name = ref("Vue Dinámico");

const counter = ref(0);
const arrayFavoritos = ref([]);
const maximoFavoritos = ref(5); // Valor máximo de favoritos

const increment = () => counter.value++;
const decrement = () => counter.value--;
const reset = () => (counter.value = 0);
const add = () => {
  if (arrayFavoritos.value.length < maximoFavoritos.value) {
    arrayFavoritos.value.push(counter.value);
  } else {
    alert("¡Alcanzaste el límite de favoritos!");
  }
};

const bloquearBtnAdd = computed(() => {
  const numSearch = arrayFavoritos.value.find((num) => num === counter.value);
  console.log(numSearch);
  return numSearch ? true : false;
});

const classCounter = computed(() => {
  if (counter.value === 0) return "zero";
  if (counter.value > 0) return "positive";
  if (counter.value < 0) return "negative";
});

const mostrarFavoritos = () => {
  $("#modalFavoritos").modal("show");
};
</script>

<template>
  <h1>Hola {{ name.toUpperCase() }}</h1>
  <h2 :class="classCounter">{{ counter }}</h2>
  <div class="btn-group">
    <button @click="increment" class="btn btn-success">Incrementar</button>
    <button @click="decrement" class="btn btn-danger">Decrementar</button>
    <button @click="reset" class="btn btn-secondary">Reiniciar</button>
    <button @click="add" :disabled="bloquearBtnAdd" class="btn btn-primary">Agregar</button>
    <button @click="mostrarFavoritos" class="btn btn-info">Ver Favoritos</button>
  </div>

  <ul class="list-group mt-4">
    <li
      class="list-group-item"
      v-for="(num, index) in arrayFavoritos"
      :key="index"
    >
      {{ num }}
    </li>
  </ul>

  <div class="modal fade" id="modalFavoritos" tabindex="-1" aria-labelledby="modalFavoritosLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalFavoritosLabel">Favoritos</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="list-group">
            <li class="list-group-item" v-for="(num, index) in arrayFavoritos" :key="index">
              {{ num }}
            </li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="button" class="btn btn-danger" @click="eliminarFavoritos">Eliminar Todos</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
h1 {
  color: aqua;
}

.positive {
  color: green;
}

.negative {
  color: red;
}

.zero {
  color: peru;
}

.modal-dialog {
  max-width: 600px;
}
</style>

